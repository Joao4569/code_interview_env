def print_number():
    print('hello')


print_number()



def century(year):
    print((year + 99) // 100)


century(1705)
