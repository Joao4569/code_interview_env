from function_library import strip_skintone_mod, extract_skintone_modifiers

strip_skintone_mod("dashkj hfdshf emoji h dfahfhfoish")
extract_skintone_modifiers("red human emoji blue pink yellow human emoji green")
